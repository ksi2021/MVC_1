<?php
$db_config = [
    'host' => 'localhost',
    'user' => 'root',
    'password' => '',
    'database' => 'slava',
    'encoding' => 'utf8'
];

define('CONFIG_DB', $db_config);