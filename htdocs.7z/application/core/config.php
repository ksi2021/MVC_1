<?php
$GLOBALS['host'] = 'localhost';
$GLOBALS['username'] = 'root';
$GLOBALS['password'] = '';
$GLOBALS['database'] = 'slava';
?>
